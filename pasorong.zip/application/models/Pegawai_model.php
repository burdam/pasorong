<?php

class Pegawai_model extends CI_Model
{
    private $_table = "pegawai";

    public function viewPegawai()
    {
        return $this->db->get($this->_table)->result_array();
    }

    public function tambahPegawai()
    {
       $data = array(
           'nip' => $this->input->post('nip', true),
           'nama' => $this->input->post('nama', true),
           'gol' => $this->input->post('gol', true),
           'divisi' => $this->input->post('divisi', true)
       );

       //masukan data yang berhasil di input tiap-tiap field
       $this->db->insert($this->_table, $data);
    }

    public function hapus($id)
    {
        $this->db->where('id', $id);
        $this->db->delete($this->_table);
    }

    public function getById($id)
    {
        return $this->db->get_where($this->_table, ['id_user' => $id])->row_array();
    }

    public function ubahPegawai()
    {
        $data = array(
            'nip' => $this->input->post('nip'),
            'nama' => $this->input->post('nama'),
            'gol' => $this->input->post('gol'),
            'divisi' => $this->input->post('divisi')
        );

        //cari id berdasarkan id yang ada dalam inputan
        $this->db->where('id_user', $this->input->post('id_user'));
        $this->db->update($this->_table, $data);

    }
}
